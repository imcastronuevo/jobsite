<?php require "../config/config.php" ?>
<?php require "../includes/header.php" ?>


<?php 
if(isset($_SESSION['username'])){
    header("Location: ".APPURL."");
}
if (isset($_POST['submit'])) {

    $email = $_POST['email'];
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        echo "<script>alert('Some inputs are missing!');</script>";
    }else{

        //checked for the form submission
        //we need to grab  the data
        //do the query with the email only
        //we are going to execute and then fetch the data
        //check for the rowcount
        //check for the password
        $login = $conn->query("SELECT * FROM users WHERE email = '$email' ");
        $login->execute();

        $select = $login->fetch(PDO::FETCH_ASSOC);

        if($login->rowCount() > 0){
            if(password_verify($password, $select['mypassword'])){
                // echo "<script>alert('Logged In! Welcome!');</script>";
                //adding Session
                $_SESSION['username'] = $select['username'];
                $_SESSION['id'] = $select['id'];
                $_SESSION['type'] = $select['type'];
                $_SESSION['email'] = $select['email'];
                $_SESSION['image'] = $select['img'];
                $_SESSION['cv'] = $select['cv'];
                header("Location: ".APPURL."");

            }else{
                echo "<script>alert('user invalid! not found!');</script>";
            }
        }else{
            echo "<script>alert('user Invalid');</script>";
        }
    }
}

?>

<section class="section-hero overlay inner-page bg-image" style="background-image: url('<?php echo APPURL; ?>/images/hero_1.jpg');" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Log In</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Log In</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section">
      <div class="container">
        <div class="row">
      
          <div class="col-md-12">
            <form action="login.php" method="POST" class="p-4 border rounded">

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="email">Email</label>
                  <input name="email" type="text" id="email" class="form-control" placeholder="Email address">
                </div>
              </div>
              <div class="row form-group mb-4">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="password">Password</label>
                  <input type="password" name="password" id="password" class="form-control" placeholder="Password">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input name="submit" type="submit" value="Log In" class="btn px-4 btn-primary text-white">
                </div>
                <a class="mx-3" href="<?php echo APPURL; ?>auth/forgot_password.php">Forgot Password?</a>

              </div>

            </form>
          </div>
        </div>
      </div>
    </section>








<?php require "../includes/footer.php"; ?>