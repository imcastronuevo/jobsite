<?php 
try{
$host = 'localhost';
$dbname = 'jobhunter';
$user = 'root';
$pass = '';


$conn = new PDO ("mysql:host=$host;dbname=$dbname", $user, $pass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //for additional error handling check php documentation

} catch (PDOException $e){
    echo "Error: " . $e->getMessage();
}



// if($conn = true){
//     echo "connected successfuly";
// }else{
//     echo "err";
// }






?>