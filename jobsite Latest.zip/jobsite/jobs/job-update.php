<?php require "../includes/header.php";?>
<?php require "../config/config.php";?>
<?php
if (isset($_SESSION['type']) && $_SESSION['type'] !== 'Company') {
    header("location:".APPURL."");
    exit();
}

$get_categories = $conn->query("SELECT * FROM categories");
$get_categories->execute();
$get_categories = $get_categories->fetchAll(PDO::FETCH_OBJ);

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $select = $conn->prepare("SELECT * FROM jobs WHERE id = :id");
    $select->bindParam(':id', $id, PDO::PARAM_INT);
    $select->execute();
    $singleJob = $select->fetch(PDO::FETCH_OBJ);

    if (isset($_SESSION['id']) && $singleJob->company_id !== $_SESSION['id']) {
        header("Location: ".APPURL."");
        exit();
    }
} else {
    echo "404";
}

if (isset($_POST['submit'])) {
    // Validate form data
    $requiredFields = ['job_title', 'job_region', 'job_type', 'vacancy', 'job_category', 'experience', 'salary', 'gender', 'application_deadline', 'job_description', 'responsibilities', 'education_experience', 'other_benifits', 'company_email', 'company_name', 'company_id', 'company_image'];

    $emptyFields = [];
    foreach ($requiredFields as $field) {
        if (empty($_POST[$field])) {
            $emptyFields[] = $field;
        }
    }

    if (!empty($emptyFields)) {
        echo "<script>alert('Empty fields: ".implode(', ', $emptyFields)."');</script>";
    } else {
        // Assign form data to variables
        $job_title = $_POST['job_title'];
        $job_region = $_POST['job_region'];
        $job_type = $_POST['job_type'];
        $vacancy = $_POST['vacancy'];
        $job_category = $_POST['job_category'];
        $experience = $_POST['experience'];
        $salary = $_POST['salary'];
        $gender = $_POST['gender'];
        $application_deadline = $_POST['application_deadline'];
        $job_description = $_POST['job_description'];
        $responsibilities = $_POST['responsibilities'];
        $education_experience = $_POST['education_experience'];
        $other_benifits = $_POST['other_benifits'];
        $company_email = $_POST['company_email'];
        $company_name = $_POST['company_name'];
        $company_id = $_POST['company_id'];
        $company_image = $_POST['company_image'];

        // Update the record in the database
        $update = $conn->prepare("UPDATE jobs SET job_title = :job_title, job_region = :job_region, job_type = :job_type, vacancy = :vacancy,
        job_category = :job_category, experience = :experience, salary = :salary, gender = :gender, application_deadline = :application_deadline,
        job_description = :job_description, responsibilities = :responsibilities, education_experience = :education_experience, other_benifits = :other_benifits,
        company_email = :company_email, company_name = :company_name, company_id = :company_id, company_image = :company_image WHERE id=:id");

        $update->bindParam(':job_title', $job_title, PDO::PARAM_STR);
        $update->bindParam(':job_region', $job_region, PDO::PARAM_STR);
        $update->bindParam(':job_type', $job_type, PDO::PARAM_STR);
        $update->bindParam(':vacancy', $vacancy, PDO::PARAM_INT);
        $update->bindParam(':job_category', $job_category, PDO::PARAM_STR);
        $update->bindParam(':experience', $experience, PDO::PARAM_STR);
        $update->bindParam(':salary', $salary, PDO::PARAM_STR);
        $update->bindParam(':gender', $gender, PDO::PARAM_STR);
        $update->bindParam(':application_deadline', $application_deadline, PDO::PARAM_STR);
        $update->bindParam(':job_description', $job_description, PDO::PARAM_STR);
        $update->bindParam(':responsibilities', $responsibilities, PDO::PARAM_STR);
        $update->bindParam(':education_experience', $education_experience, PDO::PARAM_STR);
        $update->bindParam(':other_benifits', $other_benifits, PDO::PARAM_STR);
        $update->bindParam(':company_email', $company_email, PDO::PARAM_STR);
        $update->bindParam(':company_name', $company_name, PDO::PARAM_STR);
        $update->bindParam(':company_id', $company_id, PDO::PARAM_INT);
        $update->bindParam(':company_image', $company_image, PDO::PARAM_STR);
        $update->bindParam(':id', $id, PDO::PARAM_INT);

        $update->execute();

        header("location:".APPURL."jobs/job-update.php?id=".$id."");
        exit();
    }
}
?>
<!-- HOME -->
<section class="section-hero overlay inner-page bg-image" style="background-image: url('../images/hero_1.jpg');" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Update A Job</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo APPURL;?>">Home</a> <span class="mx-2 slash">/</span>
              <a href="#">Job</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Update a Job</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section class="site-section">
      <div class="container">
        <div class="row align-items-center mb-5">
          <div class="col-lg-8 mb-4 mb-lg-0">
            <div class="d-flex align-items-center">
              <div>
                <h2>Update A Job</h2>
              </div>
            </div>
          </div>
         
        </div>
        <div class="row mb-5">
          <div class="col-lg-12">
            <form class="p-4 p-md-5 border rounded" action="job-update.php?id=<?php echo $id;?>" method="post">
            
              <!--job details-->
            
              <div class="form-group">
                <label for="job-title">Job Title</label>
                <input type="text" value="<?php echo $singleJob->job_title;?>" name="job_title" class="form-control" id="job-title" placeholder="Product Designer">
              </div>
            

              <div class="form-group">
                  <label for="job-region">Job Region</label>
                  <select name="job_region" class="selectpicker border rounded" id="job-region" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Region">
                    <?php $jobRegionOptions = ['Anywhere', 'San Francisco', 'Palo Alto', 'New York', 'Manhattan', 'Ontario', 'Toronto', 'Kansas', 'Mountain View']; ?>
                    <?php foreach($jobRegionOptions as $option) :?>
                      <option <?php echo ($option == $singleJob->job_region) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                    <?php endforeach;?>
                  </select>
              </div>

              <div class="form-group">
                <label for="job-type">Job Type</label>
                <select name="job_type" class="selectpicker border rounded" id="job-type" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Job Type">
                    <?php $jobTypeOptions = ['Part Time', 'Full Time']; ?>
                    <?php foreach($jobTypeOptions as $option) :?>
                        <option <?php echo ($option == $singleJob->job_type) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                    <?php endforeach;?>
                </select>
              </div>

              <div class="form-group">
                <label for="job-location">Vacancy</label>
                <input name="vacancy" value="<?php echo $singleJob->vacancy;?>" type="text" class="form-control" id="job-location" placeholder="e.g. 3">
              </div>
            
              <div class="form-group">
                  <label for="job-category">Job Category</label>
                  <select name="job_category" class="selectpicker border rounded" id="job-category" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Job Category">
                  <?php foreach($get_categories as $category) :?>  
                      <option <?php echo ($category->name == $singleJob->job_category) ? 'selected' : ''; ?>><?php echo $category->name;?></option>
                  <?php endforeach;?>
                  </select>
              </div>
              
              <div class="form-group">
                  <label for="experience">Experience</label>
                  <select name="experience" class="selectpicker border rounded" id="experience" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Years of Experience">
                    <?php $experienceOptions = ['1-3 years', '3-6 years', '6-9 years']; ?>
                    <?php foreach($experienceOptions as $option) :?>  
                        <option <?php echo ($option == $singleJob->experience) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                    <?php endforeach;?>
                  </select>
              </div>
              <div class="form-group">
                  <label for="salary">Salary</label>
                  <select name="salary" class="selectpicker border rounded" id="salary" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Salary">
                      <?php $salaryOptions = ['$50k - $70k', '$70k - $100k', '$100k - $150k']; ?>
                      <?php foreach($salaryOptions as $option) :?>  
                          <option <?php echo ($option == $singleJob->salary) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                      <?php endforeach;?>
                  </select>
              </div>

              <div class="form-group">
                  <label for="gender">Gender</label>
                  <select name="gender" class="selectpicker border rounded" id="gender" data-style="btn-black" data-width="100%" data-live-search="true" title="Select Gender">
                      <?php $genderOptions = ['Male', 'Female', 'Any']; ?>
                      <?php foreach($genderOptions as $option) :?>
                          <option <?php echo ($option == $singleJob->gender) ? 'selected' : ''; ?>><?php echo $option; ?></option>
                      <?php endforeach;?>
                  </select>
              </div>


              <div class="form-group">
                <label for="job-location">Application Deadline</label>
                <input name="application_deadline" value="<?php echo $singleJob->application_deadline;?>" type="text" class="form-control" id="" placeholder="e.g. 20-12-2022">
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="">Job Description</label> 
                  <textarea name="job_description"   id="" cols="30" rows="7" class="form-control" placeholder="Write Job Description..."><?php echo $singleJob->job_description;?></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="">Responsibilities</label> 
                  <textarea name="responsibilities"  id="" cols="30" rows="7" class="form-control" placeholder="Write Responsibilities..."><?php echo $singleJob->responsibilities;?></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="">Education & Experience</label> 
                  <textarea name="education_experience"  id="" cols="30" rows="7" class="form-control" placeholder="Write Education & Experience..."><?php echo $singleJob->education_experience;?></textarea>
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <label class="text-black" for="">Other Benifits</label> 
                  <textarea name="other_benifits"  id="" cols="30" rows="7" class="form-control" ><?php echo $singleJob->other_benifits;?></textarea>
                </div>
              </div>
           
              <!--company details-->


              <div class="form-group">
                <input type="hidden" value="<?php echo $_SESSION['email'];?>"name="company_email" class="form-control" id="" placeholder="Company Email">
              </div>
              <div class="form-group">
                <input type="hidden" name="company_name" value="<?php echo $_SESSION['username'];?>" class="form-control" id="" placeholder="Company Name">
              </div>
              <div class="form-group">
                <input type="hidden" name="company_id" value="<?php echo $_SESSION['id'];?>" class="form-control" id="" placeholder="Company ID">
              </div>
              <div class="form-group">
                <input type="hidden" name="company_image" value="<?php echo $_SESSION['image'];?>" class="form-control" id="" placeholder="Company Image">
              </div>
        
              
              <div class="col-lg-4 ml-auto">
                  <div class="row">  
                    <div class="col-6">
                      <input type="submit" name="submit" class="btn btn-block btn-primary btn-md" style="margin-left: 200px;" value="Update Job">
                    </div>
                  </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>
<?php require "../includes/footer.php";?>