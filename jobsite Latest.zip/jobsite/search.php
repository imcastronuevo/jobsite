<?php
require "includes/header.php";
require "config/config.php";

if (isset($_POST['submit'])) {
    if (empty($_POST['job-title']) || empty($_POST['job-region']) || empty($_POST['job-type'])) {
        header("location: " . APPURL . "");
    } else {
        $job_title = strtolower($_POST['job-title']);
        $job_region = isset($_POST['job-region']) ? strtolower($_POST['job-region']) : '';
        $job_type = isset($_POST['job-type']) ? strtolower($_POST['job-type']) : '';
        
        $insert = $conn->prepare("INSERT INTO searches (keyword) VALUES(:keyword)");
        $insert->execute([':keyword' => $job_title]);
        

   // Build the WHERE clause based on the provided search parameters
$whereClause = "LOWER(job_title) LIKE :job_title";
$parameters = [':job_title' => "%$job_title%"];

if (!empty($job_region)) {
    $whereClause .= " AND LOWER(job_region) LIKE :job_region";
    $parameters[':job_region'] = "%$job_region%";
}

if (!empty($job_type)) {
    $whereClause .= " AND LOWER(job_type) LIKE :job_type";
    $parameters[':job_type'] = "%$job_type%";
}



// Add COLLATE utf8mb4_general_ci to make the comparison case-insensitive
$search = $conn->prepare("SELECT * FROM jobs WHERE $whereClause COLLATE utf8mb4_general_ci AND status = 1");
$search->execute($parameters);
$searchRes = $search->fetchAll(PDO::FETCH_OBJ);



    }
} else {
    header("location: " . APPURL . "");
}


?>

<section class="section-hero overlay inner-page bg-image" style="background-image: url('<?php echo APPURL; ?>/images/hero_1.jpg');" id="home-section">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1 class="text-white font-weight-bold">Search results for </h1>
                <div class="custom-breadcrumbs">
                    <a href="<?php echo APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
                    <span class="text-white"><strong>Search</strong></span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="site-section">
    <div class="container">

        <ul class="job-listings mb-5">
            <?php if (!empty($searchRes)) : ?>
                <?php foreach ($searchRes as $oneJob) : ?>
                    <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
                    <a href="<?php echo APPURL; ?>/jobs/job-single.php?id=<?php echo $oneJob->id; ?>"></a>
                    <div class="job-listing-logo">
                    <img src="users/user-images/<?php echo $oneJob->company_image; ?>" alt="Free Website Template by Free-Template.co" class="img-fluid">
                    </div>

                    <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
                    <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                        <h2><?php echo $oneJob->job_title; ?></h2>
                        <strong><?php echo $oneJob->company_name; ?></strong>
                    </div>
                    <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">
                        <span class="icon-room"></span> <?php echo $oneJob->job_region; ?>
                    </div>
                    <div class="job-listing-meta">
                        <span class="badge badge-<?php if($oneJob->job_type == 'Part Time') { echo 'danger'; } else { echo 'success'; } ?>"><?php echo $oneJob->job_type; ?></span>
                    </div>
                    </div>
                    
                </li>
                    <br>
                <?php endforeach; ?>
            <?php else : ?>
                <div class="alert  bg text-dark">There are no searches with this job just yet</div>
            <?php endif; ?>
        </ul>
        <div>
</section>

<?php require "includes/footer.php"; ?>
